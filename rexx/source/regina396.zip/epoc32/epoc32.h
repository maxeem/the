#include "utsname.h"

void beep( int freq, int dur );
int epoc32_uname(struct utsname *name);
