/* config.h.  Generated from config.h.in by configure.  */
/* config.h.in.  Generated from configure.ac by autoheader.  */

/* Define if you have the <DECkeySym.h> header file */
#define HAVE_DECKEYSYM_H 1

/* Define to 1 if you have the `poll' function. */
#define HAVE_POLL 1

/* Define if you have the <Sunkeysym.h> header file */
#define HAVE_SUNKEYSYM_H 1

/* Define if you have the <XF86keysym.h> header file */
#define HAVE_XF86KEYSYM_H 1

/* Define to 1 if you have the <unistd.h> header file. */
#define HAVE_UNISTD_H 1

/* Define to 1 if you have the `usleep' function. */
#define HAVE_USLEEP 1

/* Define to 1 if you have the `vsnprintf' function. */
/* #undef HAVE_VSNPRINTF */

/* Define to 1 if you have the `vsscanf' function. */
/* #undef HAVE_VSSCANF */

/* Define if you have the <xpm.h> header file */
#define HAVE_XPM_H 1

/* Define if you want to use neXtaw library */
/* #undef USE_NEXTAW */

/* Define if you want to use Xaw3d library */
/* #undef USE_XAW3D */

/* Define XPointer is typedefed in X11/Xlib.h */
/* #undef XPOINTER_TYPEDEFED */
