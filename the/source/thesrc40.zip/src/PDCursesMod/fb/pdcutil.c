#define LINUX_FRAMEBUFFER_PORT

void PDC_check_for_blinking( void);

#include "../vt/pdcutil.c"
