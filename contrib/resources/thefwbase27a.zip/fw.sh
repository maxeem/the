#!/bin/sh
#
# fw -- bash script to call THE with the fjw macros (A. Martin 1996)
#       ported from:
#
#       fw.cmd -- Batch from FW-Macros for THE (The Hessling Editor)
#       Copyright (C) 1993-1996 Franz-Josef Wirtz
#
#
# This script is free software; see the files README and COPYING for
# details about refusing any warranty and the GNU General Public License.
#
# WHAT IS IT GOOD FOR?
# (ba|k)sh script for using the FW-macro-set
# (*besides* the THE-standard-installation)

# WHAT YOU NEED TO DO
# 1. Install THE as usual. This script assumes that the install dir of THE
#    is /usr/local/THE. If that is not your case, make a symbolic link to
#    that directory or define the suitable environment settings. If done
#    first time, be sure the environment settings are available. I.e.
#    eventually reboot or restart your shell to activate changes in your
#    profile.
# 2. Check, wether this script is executable. chmod, if it's not.
# 3. Just run this script from the current directory, which is where you've
#    installed all the other FW-macros. This will initialize
#    FW-macros. You will have to answer a few questions concerning your
#    preferences. These answers are stored for later reuse in two files
#    in your HOME-directory. (Note: THE will restart)
# 4. Copy, move or link this script to a directory in your PATH-setting.
# 5. Later, you simply may call this (fw.sh) script, a shell alias maybe
#    convenient for this.

# THERE SHOULD BE NO NEED TO EDIT THIS SCRIPT

echo "Welcome to the machine!"
echo "This is 'the' (the Hessling editor) with FW-macros in effect."
echo "The standard installation of 'the' is *not* affected."

# the following are optional to THE, if already set save old settings
if [ "$THE_HELP_FILE" != "" ]; then
      THE_OLD_HELP_FILE=$THE_HELP_FILE
fi
if [ "$THE_PROFILE_FILE" != "" ]; then
      THE_OLD_PROFILE_FILE=$THE_PROFILE_FILE
fi

# Setting the *new* environment variables specific for FW-macros (required)
#export THE_HELP_FILE=$THE_FW_HOME"/mainhelp_FW.mnu"
#export THE_PROFILE_FILE="$THE_FW_HOME/fw.the"
# this file is created by first call of the with fw.the as profile
if [ ! -w $HOME/fwrc.the -o ! -x $HOME/.fwrc ]; then
   echo
   if [ -r fw.the ]; then
      echo "'the' is called for initialization of FW-macros"
      the -k -p fw.the
      echo "'the' is called again for doing the original job"
   else
      echo "Please call this script from the directory where FW-macros are installed"
      echo "to get FW-macros initialized properly."
      exit
   fi
fi
if [ ! -x $HOME/.fwrc ]; then
   echo "$HOME/.fwrc does not exist, please initialize again"
   exit
fi
. $HOME/.fwrc

export REXXPATH=$THE_MACRO_PATH
OLDPATH=$PATH
export PATH=$PATH:$THE_MACRO_PATH
export PATH REXXPATH

# see what we've done...;-)
echo "THE_HELP_FILE="$THE_HELP_FILE
echo "THE_PROFILE_FILE="$THE_PROFILE_FILE
#wait

# Calling THE with the FW profile and soft label keys
the -k -p $THE_PROFILE_FILE $*

# restore old configuration
export PATH=$OLDPATH
if [ "$THE_OLD_HELP_FILE" != "" ]; then
    export THE_HELP_FILE=$THE_OLD_HELP_FILE
else
    unset THE_HELP_FILE
fi
if [ "$THE_OLD_PROFILE_FILE" != "" ]; then
    export THE_PROFILE_FILE=$THE_OLD_PROFILE_FILE
else
    unset THE_OLD_PROFILE_FILE
fi
