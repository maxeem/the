received by e-mail

date: 26.03.2001 16:22
from: Lucio Chiappetti <lucio@ifctr.mi.cnr.it>
subject: macros for THE input mode

I have been playing with the power input macro by Jonathan Beach  and the
"power input another version" by Homer Wilson Smith. I have the following
comments and possible variations to suggest.

Please note that I'm running in XEDIT compatibility mode on an Alpha with
Digital Unix 3.2, THE 3.0 and Regina 0.08h (and I am not in condition nor
willing to test on anything else)

(1) I have first played with the "pow" macro.
    I have noted no malfunctions, only, to tweak it to my likings, I've
    wrapped it into the following "mypow.the"

'set statopt off inputmode.1'
'macro fullmargin'
'set statopt on inputmode.1 40 4 pow=ON-'
'macro pow'
'set statopt on inputmode.1 40 4 pow=OFF-'

    essentially I like to have a flag on the status line telling whether
    power input is on or off.

    The other thing is that I'm not so interested in "real" POWERINPUT with
    line wrapping and margins (I write more code than text), so I use
    the following "fullmargin.the" macro to set margins at the physical
    size of my X11 window (which I can resize)

'extract /lscreen/'
'set margin 1 ' lscreen.2
'msg margin reset to' lscreen.2

(2) I have then played with the i.the, r.the and enter.the. I have the
    following comments :

(a) In order to use i.the and r.the one has to put 'set macro on' in .therc
    (by default is off)

(b) I do not understand (or like) the usage of the two files in home to
    keep input mode and last command across sessions. I have replaced
    them with EDITV variables.

(c) similarly to "pow" I've added a status line flag telling when input
    mode is on or off, and a few messages here and there

(d) in a sense I like these macros more than "pow" since I can freely (or
    almost) use the arrows to move on the line I'm inputting and elsewhere
    on the screen.

(e) I've noted a funny behaviour (feature) if one is inputting a line,
    and moves the cursor to another line (in the filearea or in the
    prefixarea) and presses return, a new line is sometimes inserted
    ABOVE where one expects it, depending on relative positions.

Anyhow, I enclose below the piece of .therc which I use, and in attachment the
revised macros. With this setting I'm able to use both the i/r/enter and pow
macros without apparent conflicts.

'set statopt on inputmode.1 40 4 inp=OFF-'
'set macro on'
'editv set myinputmode 0'
'editv set mylastc ""'
'define C-M macro enter'

I hope this stuff can be of some interest for some of you. I will now be
playing with some of the FW macros to choose some of my likings and integrate
with the above.

Regards

----------------------------------------------------------------------------
Lucio Chiappetti - IFCTR/CNR - via Bassini 15 - I-20133 Milano (Italy)
----------------------------------------------------------------------------
"This land .. is my land .. e no xe una portaerei"
[English in the original]  [and is not an aircraft carrier]
                             M.Paolini - I cani del gas - Bestiario italiano
----------------------------------------------------------------------------
For more info : http://www.ifctr.mi.cnr.it/~lucio/personal.html