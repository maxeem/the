Welcome -*- text -*- :-> to the CS portion of the FW-macro package for
THE, the Hessling Editor


WHAT IT IS
----------

This portion of the FW-macros handles a simple client/server usage of
THE. It is not a fully automatic server, but quite useful anyway. You
only need to have one THE session running, passing all new files to
this session. It makes use of the OS/2-utility rxqueue to establish a
named queue. Thus, this is only useful on OS/2.


WHAT YOU NEED
-------------

o a THE version as new as 2.5 (Nov 16th 1997, but older versions
  should work too)
o a REXX-system
o a file system with the capability of long filenames
o Info-Zip's Unzip 5.0 or equivalent to unzip this archive
o some free space on disk (some 10kB) for the files and some time to spend
* optional: the other parts of FW-macros


DISCLAIMER & COPYRIGHT
----------------------

This portion of FW-macros is protected by copyright (C) 1993-1998 to
Franz-Josef Wirtz.

The whole macro- and batch-package with all its files is free
software; you can redistribute it and/or modify it under the terms of
the GNU General Public License as published by the Free Software
Foundation; either version 2 of the License, or any later version.

All these macros, batches, menu- and helpfiles from the package are
distributed in the hope that they will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or
FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
for more details.

You should have received a copy of the GNU General Public License
along with this macro; if not, write to:

   The Free Software Foundation, Inc.
   675 Mass Ave,
   Cambridge, MA 02139 USA.


INSTALLATION (OS/2)
-------------------

1) Install THE as described there, i.e. setup the environment variables
   THE_HOME_DIR and THE_MACRO_PATH.

2) If you want to make use of the FW-macros in general, install the
   package as described there. If not, just proceed.

3) Unpack the files -

3a) place the batch files somewhere in your PATH. Eventually you should
    create a program icon on the desktop for thec.cmd.

3b) if you use other FW-macros:
    place the other files in THE_FW_HOME.

3c) if you don't use FW-macros in general:
    place the other files in THE_HOME_DIR. If you don't want to do so, place
    the files where you like. Then you need to have "." or the desired
    directory in your THE_MACRO_PATH to call the pq-macro.

4) Here we are:-), just start THES, the server batch, with any
   file. Then, from another shell, start THEC with another
   file. Then, go back to your THE-window. Execute the pq (process queue)
   macro. Now the other file is also loaded into this session. You can
   call pq every time you want to process the queue. There is no
   automatic call so you have a better control over what is happening.

   When you have created a program icon for THEC you can drop text
   files onto this icon to put them into the queue. You can also
   assign this batch to the plain text file type to see it in the context
   menu for plain text files....

   You don't have to start the server by hand. When THEC is called
   without a running server, it is started for you right then. So, you
   only need one icon for the client batch.

   See the *.hlp-files for more documentation.

5) Write comments and questions to me, invent new macros, menus, help
   files...., read the docs for corrections etc. Feel free to contact
   me. Send a postcard of your hometown, a picture from you, some
   lyrics... 


TRAPS AND HINTS
---------------
See the file fw_cs.hlp.


MANIFEST OF FILES
-----------------
### Info files
COPYING             - GNU General Public License
README.set          - this file
fw_cs.hlp           - help files for the client server approach

### macros
pq.the              - process queue

### batch files
thes.cmd            - THE server
thec.cmd            - THE client


CONTACT
-------
Author of this package:

Franz-Josef Wirtz,
Juelicher Str. 299,         email: fjw@ecotopia.oche.de
D-52070 Aachen,
Germany

You can also contact Mark Hessling, but he's only maintaining the
sources of THE, not these macros. Any contributors are welcome.

Mark Hessling                   Email:             M.Hessling@qut.edu.au
PO Box 203                      Phone:                    +617 3802 0800
Bellara                         http://www.gu.edu.au/gext/the/markh.html
QLD 4507                        **** Maintainer PDCurses & REXX/SQL ****
Australia                       ************* Author of THE ************

There are also mailing lists talking about THE, REXX and XEDIT and
clones in general. See the documentation for THE.

WHERE TO GET THE
----------------
THE is available from the following sites:

 North America:  ftp://uiarchive.cso.uiuc.edu/pub/packages/THE/
                 http://uiarchive.cso.uiuc.edu/
                 ftp://ftp.xylogics.com/pub/misc/THE/
 Germany:        ftp://ftp.rzg.mpg.de/pub/software/the/THE/
                 ftp://ftp.germany.eu.net/pub/comp/sysv/THE/
 Austria:        ftp://ftp.wu-wien.ac.at/pub/src/Editors/THE/
 Australia:      ftp://ftp.qut.edu.au/pub/markh/THE/
                 http://www.gu.edu.au/gext/the/markh.html

Files available:

thedos??.zip            - version ?.? DOS executable and documentation
thedjg??.zip            - version ?.? extended DOS executable and documentation
theos2??.zip            - version ?.? OS/2 executable and documentation
thew32??.zip            - version ?.? Win95/NT executable and documentation
thesrc??.zip            - source code for version ?.?
THE-?.?.tar.gz          - source code for version ?.?
thedoc??.zip            - HTML documentation for version ?.?

thedit21.zip            - version 2.1 MS-Windows 3.1 port (shareware)

The version placeholder ?? should be replaced by 24 or higher.

MANY THANKS TO
--------------
... you for trying this package

... Mark Hessling for his work done on THE and his help in
    developing this macro package.


TIMESTAMP: 05. Januar 1998
---------

Now enjoy
Franz-Josef
